// Component removed. Legal pages are now handled by InfoPage.tsx
const LegalModal = () => null;
export default LegalModal;