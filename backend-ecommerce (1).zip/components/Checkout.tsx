// Integração desativada conforme solicitação.
// Redirecionamento direto para checkout externo implementado no App.tsx.
const Checkout = () => null;
export default Checkout;